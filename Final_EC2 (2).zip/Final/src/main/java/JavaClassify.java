import org.apache.spark.ml.Pipeline;
import org.apache.spark.ml.PipelineModel;
import org.apache.spark.ml.PipelineStage;
import org.apache.spark.ml.classification.RandomForestClassificationModel;
import org.apache.spark.ml.classification.RandomForestClassifier;
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator;
import org.apache.spark.ml.feature.*;
import org.apache.spark.sql.*;

import java.io.IOException;

public class JavaClassify {

    public static void main(String[] args) throws IOException {

        // Create a SparkSession
        SparkSession spark = SparkSession
                .builder()
                .appName("RandomForestClassifierExample")
                .master("local[*]")
                .getOrCreate();

        // Load data from CSV file
        Dataset<Row> data = spark.read()
                .format("csv")
                .option("header", "true")
                .option("inferSchema", "true")
                .load("ml_files/TrainingDataset.csv");

        Dataset<Row> testData = spark.read()
                .format("csv")
                .option("header", "true")
                .option("inferSchema", "true")
                .load("ml_files/TestingDataset.csv");

        // Define the feature columns
        String[] featureColumns = {"fixed acidity", "volatile acidity", "citric acid", "residual sugar",
                "chlorides", "free sulfur dioxide", "total sulfur dioxide", "density", "pH", "sulphates", "alcohol"};

        // Define the target variable column
        String targetColumn = "quality";

        // Create a VectorAssembler to assemble the feature vector
        VectorAssembler assembler = new VectorAssembler()
                .setInputCols(featureColumns)
                .setOutputCol("features");

        // Assemble the feature vector
        Dataset<Row> assembledData = assembler.transform(data);
        Dataset<Row> assembledtestData = assembler.transform(testData);

        // Index the target variable
        StringIndexerModel indexer = new StringIndexer()
                .setInputCol(targetColumn)
                .setOutputCol("label")
                .fit(assembledData);



        // Train a RandomForestClassifier
        RandomForestClassifier rf = new RandomForestClassifier()
                .setLabelCol("label")
                .setFeaturesCol("features")
                .setNumTrees(6)
                .setImpurity("gini")
                .setSeed(42)
                ;

        // Chain the stages into a Pipeline
        Pipeline pipeline = new Pipeline()
                .setStages(new PipelineStage[]{indexer, rf});

        // Train the model
        PipelineModel model = pipeline.fit(assembledData);

        // Make predictions on the test data
        Dataset<Row> predictions = model.transform(assembledtestData);

        // Evaluate the model
        MulticlassClassificationEvaluator evaluator = new MulticlassClassificationEvaluator()
                .setLabelCol("label")
                .setPredictionCol("prediction")
                .setMetricName("accuracy");
        double accuracy = evaluator.evaluate(predictions);
        System.out.println("Accuracy: " + accuracy);

        // Save the model
        String modelPath = "ml_files/model";
        model.write().overwrite().save(modelPath);

        // Load the saved model
        PipelineModel savedModel = PipelineModel.load(modelPath);

        // Make predictions using the saved model
        Dataset<Row> newPredictions = savedModel.transform(assembledtestData);

        // Evaluate the saved model
        double newAccuracy = evaluator.evaluate(newPredictions);
        System.out.println("New accuracy after loading: " + newAccuracy);
    }
}