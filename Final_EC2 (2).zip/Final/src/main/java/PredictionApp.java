import org.apache.spark.ml.PipelineModel;
import org.apache.spark.ml.classification.RandomForestClassificationModel;
import org.apache.spark.ml.feature.StringIndexerModel;
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator;
import org.apache.spark.sql.*;
import org.apache.spark.ml.feature.*;
import org.apache.spark.sql.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

import java.io.IOException;

public class PredictionApp {

    public static void main(String[] args) throws IOException {

        // Check if the number of arguments is correct
        if (args.length != 1) {
            System.err.println("Usage: PredictionApp <path-to-data>");
            System.exit(1);
        }

        // Create a SparkSession
        SparkSession spark = SparkSession
                .builder()
                .appName("PredictionApp")
                .getOrCreate();

        // Load the saved model
        String modelPath = "ml_files/model";
        PipelineModel savedModel = PipelineModel.load(modelPath);

        // Load data from CSV file
        Dataset<Row> data = spark.read()
                .format("csv")
                .option("header", "true")
                .option("inferSchema", "true")
                .load(args[0]);

        // Define the feature columns
        String[] featureColumns = {"fixed acidity", "volatile acidity", "citric acid", "residual sugar",
                "chlorides", "free sulfur dioxide", "total sulfur dioxide", "density", "pH", "sulphates", "alcohol"};

        // Create a VectorAssembler to assemble the feature vector
        VectorAssembler assembler = new VectorAssembler()
                .setInputCols(featureColumns)
                .setOutputCol("features");

        // Assemble the feature vector
        Dataset<Row> assembledData = assembler.transform(data);

        // Make predictions using the saved model
        Dataset<Row> predictions = savedModel.transform(assembledData);

        // Select only the prediction column
        Dataset<Row> selectedPredictions = predictions.select("prediction");

        // Convert predictions to string
        Dataset<String> stringPredictions = selectedPredictions.as(Encoders.STRING());

        // Save predictions to a text file
        BufferedWriter writer = new BufferedWriter(new FileWriter("predictions.txt"));
        stringPredictions.collectAsList().forEach(prediction -> {
            try {
                writer.write(prediction);
                writer.newLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        writer.close();

        System.out.println("Predictions saved to predictions.txt");
        String inputFilePath = "predictions.txt"; // replace with your input file path
        String outputFilePath = "output.txt"; // replace with your output file path

        try (BufferedReader br = new BufferedReader(new FileReader(inputFilePath));
             BufferedWriter bw = new BufferedWriter(new FileWriter(outputFilePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                double value = Double.parseDouble(line);
                value += 3.0;
                bw.write(Double.toString(value));
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        spark.stop();
    }
}
